package com.example.demo.controller;


import com.example.demo.service.MobileFoodFacilityPermitService;
import com.example.demo.util.JsonData;
import com.example.demo.vo.MobileFoodFacilityPermitVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author ZWJ
 * @since 2024-09-27
 */
@RestController
@RequestMapping("/api/mobileFood/v1")
public class MobileFoodFacilityPermitController {

    @Autowired
    private MobileFoodFacilityPermitService mobileFoodFacilityPermitService;

    @Autowired
    private RedisTemplate redisTemplate;

    private static final String tacoKey = "truck:taco";

    /**
     * 返回所有餐车的数据
     * @param page
     * @param size
     * @return
     */
    @GetMapping("listAll")
    public JsonData listAllCar(
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "size", defaultValue = "10") int size
    ){

        Map<String,Object> pageResult = mobileFoodFacilityPermitService.page(page,size);
        return JsonData.buildSuccess(pageResult);

    }

    /**
     * 列出所有taco trucks的餐车
     * @return
     */
    @GetMapping("listAllTacoTrucks")
    public JsonData findTacoTrucks(){

        List<MobileFoodFacilityPermitVO> resultVOList = redisTemplate.opsForList().range(tacoKey,-1, 0);

        if(null == resultVOList || resultVOList.size() ==0){
            resultVOList = mobileFoodFacilityPermitService.findTacoTrucks();
            redisTemplate.opsForList().rightPush(tacoKey,resultVOList);
        }

        return JsonData.buildSuccess(resultVOList);
    }

    /**
     *
     * @param locationid
     * @return
     */
    @GetMapping("foodDetails/{locationid}")
    public JsonData foodDetails(@PathVariable("locationid")int locationid){

        String[] items = mobileFoodFacilityPermitService.getFoodDetailByLocationid(locationid);

        return JsonData.buildSuccess(items);
    }

}

