package com.example.demo.service;

import com.example.demo.util.JsonData;
import com.example.demo.vo.MobileFoodFacilityPermitVO;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ZWJ
 * @since 2024-09-27
 */
public interface MobileFoodFacilityPermitService {

    JsonData listAll();

    Map<String,Object> page(int page, int size);

    List<MobileFoodFacilityPermitVO> findTacoTrucks();

    String[] getFoodDetailByLocationid(int locationid);
}
