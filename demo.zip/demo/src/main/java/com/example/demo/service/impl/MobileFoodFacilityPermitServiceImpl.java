package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.mapper.MobileFoodFacilityPermitMapper;
import com.example.demo.model.MobileFoodFacilityPermitDO;
import com.example.demo.service.MobileFoodFacilityPermitService;
import com.example.demo.util.JsonData;
import com.example.demo.vo.MobileFoodFacilityPermitVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ZWJ
 * @since 2024-09-27
 */
@Service
public class MobileFoodFacilityPermitServiceImpl implements MobileFoodFacilityPermitService {

    @Autowired
    private MobileFoodFacilityPermitMapper mobileFoodFacilityPermitMapper;

    @Override
    public JsonData listAll() {

        List<MobileFoodFacilityPermitDO> bannerDOList =  mobileFoodFacilityPermitMapper.selectList(new QueryWrapper<MobileFoodFacilityPermitDO>().orderByAsc("locationid"));
        return null;
    }

    @Override
    public Map<String, Object> page(int page, int size) {
        Page<MobileFoodFacilityPermitDO> pageInfo = new Page<>(page,size);

        IPage<MobileFoodFacilityPermitDO> mobileFoodFacilityPermitDOIPage =  mobileFoodFacilityPermitMapper.selectPage(pageInfo,null);

        Map<String,Object> pageMap = new HashMap<>(3);

        pageMap.put("total_record",mobileFoodFacilityPermitDOIPage.getTotal());
        pageMap.put("total_page",mobileFoodFacilityPermitDOIPage.getPages());
        pageMap.put("current_data",mobileFoodFacilityPermitDOIPage.getRecords().stream().map(obj->beanProcess(obj)).collect(Collectors.toList()));

        return pageMap;
    }

    @Override
    public List<MobileFoodFacilityPermitVO> findTacoTrucks() {

        List<MobileFoodFacilityPermitDO> resultList = mobileFoodFacilityPermitMapper.selectList(new QueryWrapper<MobileFoodFacilityPermitDO>().like("FoodItems","taco"));

        List<MobileFoodFacilityPermitVO> resultVOList = resultList.stream().map(obj->beanProcess(obj)).collect(Collectors.toList());
        return resultVOList;
    }

    @Override
    public String[] getFoodDetailByLocationid(int locationid) {

        MobileFoodFacilityPermitDO mobileFoodFacilityPermitDO =mobileFoodFacilityPermitMapper.selectById(locationid);

        String foodItem = mobileFoodFacilityPermitDO.getFooditems();
        String[] items = foodItem.split(":");
        return items;
    }

    private MobileFoodFacilityPermitVO beanProcess(MobileFoodFacilityPermitDO mobileFoodFacilityPermitDO) {

        MobileFoodFacilityPermitVO mobileFoodFacilityPermitVO = new MobileFoodFacilityPermitVO();
        BeanUtils.copyProperties(mobileFoodFacilityPermitDO,mobileFoodFacilityPermitVO);
        return mobileFoodFacilityPermitVO;
    }
}
