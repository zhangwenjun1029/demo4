package com.example.demo.model;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author ZWJ
 * @since 2024-09-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("mobile_food_facility_permit")
public class MobileFoodFacilityPermitDO implements Serializable {

    private static final long serialVersionUID = 1L;

      @TableId(value = "locationid", type = IdType.AUTO)
    private Integer locationid;

    @TableField("Applicant")
    private String applicant;

    @TableField("FacilityType")
    private String facilitytype;

    private Integer cnn;

    @TableField("LocationDescription")
    private String locationdescription;

    @TableField("Address")
    private String address;

    private String blocklot;

    private String block;

    private String lot;

    private String permit;

    @TableField("Status")
    private String status;

    @TableField("FoodItems")
    private String fooditems;

    private Double x;

    private Double y;

    @TableField("Latitude")
    private Double latitude;

    @TableField("Longitude")
    private Double longitude;

    @TableField("Schedule")
    private String schedule;

    private String dayshours;

    @TableField("NOISent")
    private String noisent;

    @TableField("Approved")
    private String approved;

    @TableField("Received")
    private Integer received;

    @TableField("Prior_Permit")
    private Integer priorPermit;

    @TableField("ExpirationDate")
    private String expirationdate;

    @TableField("Location")
    private String location;

    @TableField("Fire_Prevention_Districts")
    private Integer firePreventionDistricts;

    @TableField("Police_Districts")
    private Integer policeDistricts;

    @TableField("Supervisor_Districts")
    private Integer supervisorDistricts;

    @TableField("Zip_Codes")
    private Integer zipCodes;

    @TableField("Neighborhoods_old")
    private Integer neighborhoodsOld;


}
