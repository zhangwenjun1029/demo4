package com.example.demo.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ZWJ
 * @since 2024-09-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MobileFoodFacilityPermitVO implements Serializable {


    private Integer locationid;

    private String applicant;

    private String facilitytype;

    private Integer cnn;

    private String locationdescription;

    private String address;

    private String blocklot;

    private String block;

    private String lot;

    private String permit;

    private String status;

    private String fooditems;

    private Double x;

    private Double y;

    private Double latitude;

    private Double longitude;

    private String schedule;

    private String dayshours;

    private String noisent;

    private String approved;

    private Integer received;

    private Integer priorPermit;

    private String expirationdate;

    private String location;

    private Integer firePreventionDistricts;

    private Integer policeDistricts;

    private Integer supervisorDistricts;

    private Integer zipCodes;

    private Integer neighborhoodsOld;


}
