package com.example.demo.mapper;

import com.example.demo.model.MobileFoodFacilityPermitDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ZWJ
 * @since 2024-09-27
 */
public interface MobileFoodFacilityPermitMapper extends BaseMapper<MobileFoodFacilityPermitDO> {

}
